clear
close all
clc

addpath '/Users/ncai/OneDrive/Scripts/bin/'
addpath '/Users/ncai/OneDrive/Database/NOAA_COOPS/'
addpath '/Users/ncai/OneDrive/Scripts/bin/T_Tides/'
%addpath '/Users/ncai/OneDrive/Scripts/bin/t_tide_v1/'

path_cloud='/Users/ncai/OneDrive/Projects/USEC/results/';

%----------inputs------------
isave=0;
run='run05a'; 
iscomb=1; %1: combine {run}_?
nruns=7; %# of sub runs
year_ori=2001; %from model start time
year_start=2001; %for window
nyear=3; %duration for window

isold=2; %1: 57 NOAA stations; 2: 64 stations
ileg=1; %legend

%-----figure parameters-----
fpostion=[1,1,1400,800];
nfontsize=22;
clbase=bl2rd_scaled(64);

%-----------------------------
path=[path_cloud,run,'/'];
time_ori=datenum(['01/01/',num2str(year_ori),' 00:00:00']);
time_ref=datenum(['01/01/',num2str(year_start),' 00:00:00']);
%window=time_ref:(1/24):(time_ref+nyear*365);
time_left=datenum(['01/01/2014 00:00:00']);
time_right=datenum(['01/15/2014 00:00:00']);
window=time_left:(1/24):time_right;

%------------read in station info------------
if isold==1
    load('/Users/ncai/OneDrive/Database/NOAA_COOPS/NOAA_COOPS_USEC_old.mat')
else
    load('/Users/ncai/OneDrive/Database/NOAA_COOPS/NOAA_COOPS_USEC.mat')
end
nsta=length(staid);

%--------------------------------------------------------------------
%load model + obs
%--------------------------------------------------------------------

%------------load model results; prep for HA------------
if iscomb==0
    fname=[run,'_elev_sta.mat'];
    load([path,fname]) 
    mtime=T/86400; clear T
    mvar=var; clear var
    mtime=time_ori+mtime;
elseif iscomb==1
    mtime=[];mvar=[];
    for r1=1:nruns
        subrun=[run,'_',num2str(r1)];
        fname=[subrun,'_elev_sta.mat'];
        load([path_cloud,subrun,'/',fname]) 
        submtime=T/86400; clear T
        submvar=var; clear var
        if r1==1
            submtime=time_ori+submtime;
            mtime=[mtime;submtime];
        else
            submtime=mtime(end)+submtime;
            mtime=[mtime;submtime];
        end
        mvar=[mvar;submvar];
    end %r1::nruns
end %iscomb

%force time step = 1 hour
mintvar=interp1(mtime,mvar,window,'linear','extrap');

%------------read in NOAA COOPS database; prep for HA------------
ointvar=zeros(length(window),nsta);
for r1=1:nsta
    [otime,ovar]=NOAA_COOPS_TSeries(staid(r1),window(1)-1,window(end)+1);
    ointvar(:,r1)=interp1(otime,ovar,window);%force time step = 1 hour
end %r1::sta


%--------------------------------------------------------------------
%Time series plots
%--------------------------------------------------------------------
stapk=[1:4 21  27 28 33 34 38 39 44 45 49 51 52 57 58 63 64];
fpostion=[1,1,1400,1200];
figure('Position',fpostion);
for r1=1:length(stapk) 
    r2=stapk(r1);
    subplot(5,4,r1)
    plot(window,mintvar(:,r2),'LineWidth',1.5)
    hold on
    plot(window,ointvar(:,r2),'LineWidth',1.5)
    xlim([window(1) window(end)])
    if r1>15
        datetick('x','mm/dd/yyyy','keeplimits') 
    else
        xticks([])
    end
    if r1==9
        ylabel('Elevation (m)')
    end
    title(num2str(staid(r2)))
    if r1==4 && ileg==1
        legend('model','observation')
    end
    set(gca,'fontsize',18);
end %r1::sta

if isave==1
    outname=[run,'_USEC_Elevation_TSeries'];
    set(gcf,'PaperPositionMode','auto') 
    print('-dpng',[path,outname,'.png'],'-r300')
end
