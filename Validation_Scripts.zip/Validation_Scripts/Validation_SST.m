clear
close all
clc

lversion=3; %loading version
path_grid=['/Users/ncai/OneDrive/Projects/USEC/Grid_v',num2str(lversion),'/'];
hgridmat=['Grid_v',num2str(lversion)];

path_obs='/Users/ncai/Documents/NOAA_OI_SST/';
path_md='/Users/ncai/Documents/USEC/results/';
path_cloud='/Users/ncai/OneDrive/Projects/USEC/results/';

pyear=2015;
run='run05a_5';

ifig=[2]; %1: mean; 2: picked day
isave=[2];

%figure properties
figuresize=[1,1,1100,380];
nfontsize=18;
ileg=1; %legend

%-----------------------------------------------------------
%read grid
%-----------------------------------------------------------
if exist([path_grid,hgridmat,'.mat'],'file')
    load([path_grid,hgridmat,'.mat']);
else
    errmsg='call LoadGrid at /Users/ncai/OneDrive/Scripts/USEC/ReadLoadings/';
    error(errmsg)
end
maxlon=max(lonlat(:,2));minlon=min(lonlat(:,2));
maxlat=max(lonlat(:,3));minlat=min(lonlat(:,3));
mdxy=[x y]; clear x y
%-----------------------------------------------------------


%-----------------------------------------------------------
%read NOAA lon/lat to x/y; find points for assessments; load SST
%-----------------------------------------------------------
filename=[path_obs,'sst.day.mean.',num2str(pyear),'.nc'];
obslon=ncread(filename,'lon'); obslat=ncread(filename,'lat'); 
obslon(obslon>180)=obslon(obslon>180)-360;
obsSST=ncread(filename,'sst'); 

%filter with max/min
idlon=(obslon<=maxlon).*(obslon>=minlon);
idlat=(obslat<=maxlat).*(obslat>=minlat);
obslon=obslon(idlon==1);obslat=obslat(idlat==1);
nlon=length(obslon); nlat=length(obslat);
obsSST=squeeze(obsSST(idlon==1,idlat==1,:));
obsSST(obsSST<-99)=nan;
obsmSST=mean(obsSST,3,'omitnan');
obstSST=reshape(obsSST,length(obslon)*length(obslat),365);

%convert to x/y
utmZone18N = projcrs(26918);
[obslonT, obslatT] = ndgrid(obslon, obslat); 
[obsxy(:,1), obsxy(:,2)] = projfwd(utmZone18N, obslatT(:), obslonT(:));
dist=vecnorm(diff(obsxy,1,1), 2, 2);
dist(dist>100000)=nan;
mdist=mean(dist,'omitnan');
%pcolor(obslonT,obslatT,obsmSST,'FaceColor','Interp','EdgeColor','none')
%-----------------------------------------------------------


%-----------------------------------------------------------
%find model nd(s) for each obs pt
%-----------------------------------------------------------
dist2=pdist2(mdxy,obsxy);
mid=dist2 <= mdist;
%-----------------------------------------------------------

%%
%-----------------------------------------------------------
%take md with daily mean
%-----------------------------------------------------------
mdtvar=[]; mdtime=[];
for istack=41:60 
    filename=[path_md,run,'/',run,'_temperature_surf_Zlayer_',num2str(istack),'.mat'];
    load(filename) 
    a=['read ' filename]
    mdtvar=[mdtvar;var]; clear var time
end %istack
%%
mdtvar(mdtvar<-90)=nan;
mddvar=reshape(mdtvar,4,365,length(mdtvar(1,:)));
mddvar=permute(mddvar, [1 3 2]);  %4*nodes*365
%mdvar=mean(mddvar,1,'omitnan'); mdvar=squeeze(mdvar(1,:,:));
%-----------------------------------------------------------

%%
%-----------------------------------------------------------
%Loop over obs for spatial mean from md
%-----------------------------------------------------------
abserrt=nan(length(obsmSST(:)),365);
for r1=1:length(obsmSST(:))
        kmid=mid(:,r1);    
        mtmp=squeeze(mddvar(:,kmid,:));        
        otmp=obstSST(r1,:);  
        if ~isempty(mtmp)
            mtmp=reshape(mtmp,4*sum(kmid),365);
            err=abs(mtmp- otmp);
            abserrt(r1,:)= min(abs(mtmp- otmp));   
        end
end %r1:: obs points
abserr=reshape(abserrt,length(obslon),length(obslat),365);
Mabserr=mean(abserr,3);
MMasberr=mean(mean(Mabserr,'omitnan'),'omitnan')
Vabserr=~isnan(abserrt(:,1));
for r2=1:365
    rmse(r2)=sqrt(sum(abserrt(:,r2).^2,'omitnan')/sum(Vabserr));
end
Mrmse=mean(rmse,2,'omitnan')
%-----------------------------------------------------------
% figure; pcolor(obslonT,obslatT,Mabserr,'FaceColor','Interp','EdgeColor','none'); colorbar
% figure; pcolor(obslonT,obslatT,obsmSST,'FaceColor','Interp','EdgeColor','none'); colorbar

%%
%-----------------------------------------------------------
%x/y resolution
%-----------------------------------------------------------
obslonTN=mean(reshape(obslonT,2,[],nlat),1);
obslonTN=squeeze(obslonTN);
obslonTN=obslonTN(:,1:end-1);
obslonTN=obslonTN';
obslonTN=mean(reshape(obslonTN,2,[],nlon/2),1);
obslonTN=squeeze(obslonTN);
obslonTN=obslonTN';

obslatTN=mean(reshape(obslatT,2,[],nlat),1);
obslatTN=squeeze(obslatTN);
obslatTN=obslatTN(:,1:end-1);
obslatTN=obslatTN';
obslatTN=mean(reshape(obslatTN,2,[],nlon/2),1);
obslatTN=squeeze(obslatTN);
obslatTN=obslatTN';

obsnSST=mean(reshape(obsmSST,2,[],nlat),1);
obsnSST=squeeze(obsnSST);
obsnSST=obsnSST(:,1:end-1);
obsnSST=obsnSST';
obsnSST=mean(reshape(obsnSST,2,[],nlon/2),1);
obsnSST=squeeze(obsnSST);
obsnSST=obsnSST';

MNabserr=mean(reshape(Mabserr,2,[],nlat),1);
MNabserr=squeeze(MNabserr);
MNabserr=MNabserr(:,1:end-1);
MNabserr=MNabserr';
MNabserr=mean(reshape(MNabserr,2,[],nlon/2),1);
MNabserr=squeeze(MNabserr);
MNabserr=MNabserr';

obstnSST=mean(reshape(obsSST,2,[],nlat,365),1);
obstnSST=squeeze(obstnSST);
obstnSST=obstnSST(:,1:end-1,:);
obstnSST=permute(obstnSST, [2 1 3]); 
obstnSST=mean(reshape(obstnSST,2,[],nlon/2,365),1);
obstnSST=squeeze(obstnSST);
obstnSST=permute(obstnSST, [2 1 3]); 

NTabserr=mean(reshape(abserr,2,[],nlat,365),1);
NTabserr=squeeze(NTabserr);
NTabserr=NTabserr(:,1:end-1,:);
NTabserr=permute(NTabserr, [2 1 3]); 
NTabserr=mean(reshape(NTabserr,2,[],nlon/2,365),1);
NTabserr=squeeze(NTabserr);
NTabserr=permute(NTabserr, [2 1 3]); 

if ismember(1,ifig)
    figure('Position',figuresize);
    subplot(1,2,1)
    pcolor(obslonTN,obslatTN,obsnSST,'FaceColor','Interp','EdgeColor','none'); colorbar
    title('(a) Annual mean observation (^oC)')
    xlabel('Longitude'); ylabel('Latitude')
    set(gca,'fontsize',nfontsize);  
    subplot(1,2,2)
    pcolor(obslonTN,obslatTN,MNabserr,'FaceColor','Interp','EdgeColor','none'); colorbar
    title('(b) Annual mean absolute error (^oC)')
    xlabel('Longitude'); ylabel('Latitude')
    set(gca,'fontsize',nfontsize);  
    if ismember(1,isave)
        outname=[run,'_USEC_SST_mean'];
        set(gcf,'PaperPositionMode','auto') 
        print('-dpng',[path_cloud,run,'/',outname,'.png'],'-r300')
    end
end %ifig

if ismember(2,ifig)
    pkday=[100 200 300];%[90 180 270 360]; %[75 150 225 300];
    for iday=pkday
        rid=find(pkday==iday);
        figure('Position',figuresize);
        subplot(1,2,1)
        pcolor(obslonTN,obslatTN,obstnSST(:,:,iday),'FaceColor','Interp','EdgeColor','none'); colorbar
        text(-80,44,['Day ',num2str(iday)],'VerticalAlignment', 'middle','HorizontalAlignment','left','FontSize', 18)
        title(['(a-',num2str(rid),') NOAA observation (^oC)'])
        xlabel('Longitude'); ylabel('Latitude')
        set(gca,'fontsize',nfontsize);  
        subplot(1,2,2)
        pcolor(obslonTN,obslatTN,NTabserr(:,:,iday),'FaceColor','Interp','EdgeColor','none'); colorbar
        title(['(b-',num2str(rid),') Mean absolute error (^oC)'])
        clim([0 2.9])
        xlabel('Longitude'); ylabel('Latitude')
        set(gca,'fontsize',nfontsize);  
        if ismember(2,isave)
            outname=[run,'_USEC_SST_day',num2str(iday)];
            set(gcf,'PaperPositionMode','auto') 
            print('-dpng',[path_cloud,run,'/',outname,'.png'],'-r300')
        end
    end %iday
end %ifig
%-----------------------------------------------------------
