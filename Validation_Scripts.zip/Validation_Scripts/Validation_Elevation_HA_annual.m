clear
close all
clc

addpath '/Users/ncai/OneDrive/Scripts/bin/'
addpath '/Users/ncai/OneDrive/Database/NOAA_COOPS/'
addpath '/Users/ncai/OneDrive/Scripts/bin/T_Tides/'
%addpath '/Users/ncai/OneDrive/Scripts/bin/t_tide_v1/'

path_cloud='/Users/ncai/OneDrive/Projects/USEC/results/';

%----------inputs------------
% 1:: x-stationn, y-amp/phase; 2:: x-obs, y-model; 
% 3: error histogram; 4: error of selected constituent
ifig=[ 2 ]; 
isave=[ ];
run='run05a'; 
iscomb=1; %1: combine {run}_?
nruns=7; %# of sub runs
year_ori=2001; %from model start time
time_ori=datenum(['01/01/',num2str(year_ori),' 00:00:00']);
nyear=3;

%-----figure parameters-----
fpostion=[1,1,1400,800];
nfontsize=20;
clbase=bl2rd_scaled(32);
%-----------------------------

%-----HA parameters-----
path=[path_cloud,run,'/'];
if ~exist([path,'HA_year'])
    mkdir([path,'HA_year']);
end %exist

constituents={'Q1' 'O1' 'P1' 'K1' 'N2' 'M2' 'S2' 'K2'};
Period=[26.87 25.82 24.07 23.93 12.66 12.42 12 11.97];
cMap=[1:8];
submap=[0 0 0 0 0 1 0 0];  %determines which constituents appear in the subplots
titleStr=cell(length(constituents),2);
%-----------------------------


%------------read in station info------------
load('/Users/ncai/OneDrive/Database/NOAA_COOPS/NOAA_COOPS_USEC.mat')
nsta=length(staid);
tstapk=[1:4 6:10 12:16 18 19:25 27:31 32:39 41:54 57 59 60 61 63 64];


%--------------------------------------------------------------------
%HA
%--------------------------------------------------------------------
if ~exist([path,'HA_year/','HA_year.mat'],'file')    
    
    %--------------------------------------------------------------------
    %load model results
    %--------------------------------------------------------------------
    mtime=[];mvar=[];
    if iscomb==0
        fname=[run,'_elev_sta.mat'];
        load([path_cloud,run,'/',fname]) 
        mtime=T/86400; clear T
        mtime=time_ori+mtime;
        mvar=var; clear var
    elseif iscomb==1
        for r1=1:nruns
            subrun=[run,'_',num2str(r1)];
            fname=[subrun,'_elev_sta.mat'];
            load([path_cloud,subrun,'/',fname]) 
            submtime=T/86400; clear T
            submvar=var; clear var
            if r1==1
                submtime=time_ori+submtime;
                mtime=[mtime;submtime];
            else
                submtime=mtime(end)+submtime;
                mtime=[mtime;submtime];
            end
            mvar=[mvar;submvar];
        end %r1::nruns
    end %iscomb

    obs_amp=nan(nsta,length(constituents),nyear);
    obs_phase=nan(nsta,length(constituents),nyear);
    st_amp=nan(nsta,length(constituents),nyear);
    st_phase=nan(nsta,length(constituents),nyear);
    for yy=1:nyear
        %-----------renew time-----------
        time_ref=datenum(['01/01/',num2str(yy+2000),' 00:00:00']);
        window=time_ref:(1/24):(time_ref+365);
        startTime=window(1);
        endTime=window(end);
        startYear=str2num(datestr(startTime,'yyyy'));
        startMonth=str2num(datestr(startTime,'mm'));
        startDay=str2num(datestr(startTime,'dd'));
        startHour=str2num(datestr(startTime,'HH'));
        startMin=str2num(datestr(startTime,'MM'));
        startSec=str2num(datestr(startTime,'SS'));
    
        %-----------HA process and store original outputs-----------
        if ~exist([path,'HA_year/','HA_',num2str(startYear),'.mat'],'file')    
        
            %-----------pick model results-----------
            mintvar=interp1(mtime,mvar,window,'linear','extrap');
        
            %-----------pick obs results-----------
            ointvar=zeros(length(window),nsta);
            for r1=1:length(staid)    
                [otime,ovar]=NOAA_COOPS_TSeries(staid(r1),window(1)-1,window(end)+1);
                ointvar(:,r1)=interp1(otime,ovar,window);%force time step = 1 hour      
            end %r1::sta
            ointnan=~isnan(ointvar);tointnan=sum(ointnan,1);
            stapk=find(tointnan>360*24); %more than 360 days of record
            tsta=length(stapk);
    
            %model
            for r1=1:nsta
                [tidestruc(:,r1), xout(:,r1)]=t_tide(mintvar(:,r1), 'interval',1, 'start time', ...
                    [startYear, startMonth, startDay, startHour, startMin, startSec], ...
                    'latitude', floor(stall(r1,2)), 'rayleigh',  ...
                    constituents, ...
                    'output', [path,'HA_year/',num2str(staid(r1)),'_',num2str(startYear),'_mod']);    
            end %r1::nsta
            
            %obs
            for r1=1:nsta
                if ismember(r1,stapk)
                    %find start time of available onbs
                    aa=find(ointnan(:,r1)==1);
                    ostartYear=str2num(datestr(window(aa(1)),'yyyy'));
                    ostartMonth=str2num(datestr(window(aa(1)),'mm'));
                    ostartDay=str2num(datestr(window(aa(1)),'dd'));
                    ostartHour=str2num(datestr(window(aa(1)),'HH'));
                    ostartMin=str2num(datestr(window(aa(1)),'MM'));
                    ostartSec=str2num(datestr(window(aa(1)),'SS'));
                    
                    bb=[];
                    a=aa(1);
                    while a<aa(end)
                        bb=[bb;a];
                        a=a+1;
                        if ~ismember(a,aa) 
                            if length(bb)>360*24
                                break;
                            else
                                bb=[];
                                aid=find(aa==(a-1));
                                a=aa(aid+1);
                            end %sufficient obs
                        end %ismember
                    end %aa
                    ointvar_pk=ointvar(bb,r1);
            
                    [tidestrucObs(:,r1), ~]=t_tide(ointvar_pk, 'interval',1, 'start time', ...
                        [ostartYear, ostartMonth, ostartDay, ostartHour, ostartMin, ostartSec],  ...
                        'latitude', floor(stall(r1,2)), 'rayleigh',  ...
                        constituents, ...
                        'output', [path,'HA_year/',num2str(staid(r1)),'_',num2str(startYear),'_obs']);
                end %stapk
            end %r1::nsta
        
            %store 
            save([path,'HA_year/','HA_',num2str(startYear),'.mat'],'tidestrucObs','tidestruc')
        else
            load([path,'HA_year/','HA_',num2str(startYear),'.mat'])
        end % exists
    
        %-----------pick and store HA results-----------  
            for r1=1:nsta
                for k=1:length(constituents)
                    if ~isempty(tidestrucObs(r1).tidecon)
                        obs_amp(r1,k,yy)=tidestrucObs(r1).tidecon(k,1);
                        obs_phase(r1,k,yy)=tidestrucObs(r1).tidecon(k,3);
                    end %isempty
                    st_amp(r1,k,yy)=tidestruc(r1).tidecon(k,1);
                    st_phase(r1,k,yy)=tidestruc(r1).tidecon(k,3);
                end %constituents
            end %r1::nsta        
    end %yy::year
    save([path,'HA_year/','HA_year.mat'],'st_phase','st_amp','obs_phase','obs_amp')
else
    load([path,'HA_year/','HA_year.mat'])
end %exist:: HA_year


%--------------------------------------------------------------------
%plot
%--------------------------------------------------------------------

if ismember(1,ifig)
    cid=[6]; %M2,K1,K2,O1
    ypk=3;
    fsize=[1,1,1500,250*length(cid)];
    figure('Position',fsize)
    for cc=1:length(cid)
        subplot(length(cid),1,cc)
        for yy=ypk %1:nyear    
            obs=squeeze(obs_amp(:,:,yy));
            st=squeeze(st_amp(:,:,yy));
            aid=find(~isnan(obs(:,1)));
            aid=intersect(aid,tstapk);
            
            scatter(1:length(aid),st(aid,cid(cc)),120,clbase(1,:),'x','LineWidth',2); hold on;
            scatter(1:length(aid),obs(aid,cid(cc)),120,clbase(2,:),'o','LineWidth',2); hold on;
            set(gca,'Xtick',[1:length(aid)],'XtickLabel',num2str(staid(aid)));
            title('M2 Amplitude (m)')
            %title(constituents{cid(cc)})
            box on;
            xlim([0 length(aid)+1])
            set(gca,'fontsize',nfontsize);
            legend({'Model','Observation'},'Location','northwest');
        end %yy::nyear
    end %cc::cid
    if ismember(1,isave)
        outname=[run,'_USEC_HA_M2_year',num2str(2000+ypk)];
        set(gcf,'PaperPositionMode','auto') 
        print('-dpng',[path,outname,'.png'],'-r300')
    end %isave    
end %ifig


if ismember(2,ifig)
    cid(1:4,1)=[1:4]; cid(1:3,2)=[5 7 8];
    ypk=3; %1:20;
    fsize=[1,1,900,360];
    figure('Position',fsize)
    for ss=1:2
        tobs=[]; tst=[];
        subplot(1,2,ss)
        x=0:1:4; y=0:1:4;
        plot(x,y,'LineStyle','-','Color','k','LineWidth',2);hold on
        for cc=1:sum(cid(:,ss)>0)
            for yy=ypk %1:nyear    
                %-----------------amp-----------------
                obs=squeeze(obs_amp(:,:,yy));
                st=squeeze(st_amp(:,:,yy));
                aid=find(~isnan(obs(:,1)));
                aid=intersect(aid,tstapk);
                scatter(obs(aid,cid(cc,ss)),st(aid,cid(cc,ss)),320,clbase(4*cid(cc,ss),:),'.'); hold on;
                tobs=[tobs;obs(aid,cid(cc,ss))]; tst=[tst;st(aid,cid(cc,ss))];
            end %yy::nyear
        end %cc::cid

        [r, p] = corr(tobs, tst, 'Type', 'Pearson'); % 'Pearson' is the default

        % Compute the R-square
        r_square = r^2;

        % Display results
        fprintf('Correlation Coefficient (r): %.4f\n', r);
        fprintf('P-value: %.4f\n', p);
        fprintf('R-square: %.4f\n', r_square);

        %--figure properties--
        box on
        xlabel('Observation')
        ylabel('Model')
        if ss==2
            xlim([0 0.8]); ylim([0 0.8])
        else
            xlim([0 0.15]); ylim([0 0.15])
        end
        set(gca,'fontsize',nfontsize);
    end %ss::subplot

    if ismember(2,isave)
        outname=[run,'_USEC_HA_year_constituents'];
        set(gcf,'PaperPositionMode','auto') 
        print('-dpng',[path,outname,'.png'],'-r300')
    end %isave

    
    figure
    x=nan(7,1); x(:,1)=1;
    y=7:-1:1; 
    cid0=[1:5 7 8]
    for cc=1:7
        scatter(x(cc),y(cc),500,clbase(4*cid0(cc),:),'.'); hold on
        text(x(cc)+0.2,y(cc),constituents{cid(cc)},'FontSize',20,'HorizontalAlignment','left')
    end %cc::cid
    xlim([0 4])
    ylim([0 8])
    set(gca,'fontsize',nfontsize);
    if ismember(2,isave)
        outname=[run,'_USEC_HA_legend'];
        set(gcf,'PaperPositionMode','auto') 
        print('-dpng',[path,outname,'.png'],'-r300')
    end %isave
end %ifig


if ismember(3,ifig)
    cid=1:8;
    ypk=1:20;
    diff=[];
    %diff=st_amp(:,:,ypk)-obs_amp(:,:,ypk);
    for yy=ypk
        tmp=st_amp(tstapk,:,yy)-obs_amp(tstapk,:,yy);
        diff=[diff;tmp];
    end %yy::nyear

    fsize=[1,1,450,360];
    figure('Position',fsize)
    histogram(diff,100)
    %xlim([-0.2 0.3])
    ylabel('Counts')
    xlabel('Error (m)')
    set(gca,'fontsize',nfontsize);
    if ismember(3,isave)
        outname=[run,'_USEC_HA_histogram'];
        set(gcf,'PaperPositionMode','auto') 
        print('-dpng',[path,outname,'.png'],'-r300')
    end %isave
end %ifig


if ismember(4,ifig)
    cid=6;
    ypk=1:20;
    sthere=squeeze(st_amp(tstapk,cid,ypk));
    sthere=reshape(sthere,[],1);
    obshere=squeeze(obs_amp(tstapk,cid,ypk));
    obshere=reshape(obshere,[],1);
    merr=rmse(sthere,obshere,'omitnan');
    diff=abs(sthere-obshere);

    fsize=[1,1,450,360];
    figure('Position',fsize)
    histogram(merr,40)
    legend(['RMSE = ',num2str(merr)])

    set(gca,'fontsize',nfontsize);
    if ismember(3,isave)
        outname=[run,'_USEC_HA_histogram'];
        set(gcf,'PaperPositionMode','auto') 
        print('-dpng',[path,outname,'.png'],'-r300')
    end %isave

end %ifig

