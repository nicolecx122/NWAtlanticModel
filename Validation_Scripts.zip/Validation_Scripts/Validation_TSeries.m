clear
close all
clc
addpath '/Users/ncai/OneDrive/Scripts/bin/'
addpath '/Users/ncai/OneDrive/Database/Ches_Database/CBP_database/'
addpath '/Users/ncai/OneDrive/Database/NERR/'
addpath '/Users/ncai/OneDrive/Database/NOAA_ERDDAP/bin/'
addpath '/Users/ncai/OneDrive/Database/NC_APES_ModMon/'
addpath '/Users/ncai/OneDrive/Database/USGS_WQ/bin/'

path_cloud='/Users/ncai/OneDrive/Projects/USEC/results/';

%----------inputs------------
isave=0;%flag to save the figure, png
isicm=0;
isregion=5;%[ 1:6]; %1: ChesBay main stem; 2: Ches tribs; 3: NERR_USEC; 4: ERDDAP_USEC; 5: NC APES; 6:USGSDB
regions={'CBP','CBPTribs','NERR','ERDDAP','APES','USGSDB'};

run={'run05a'}; 
iscomb=1; %1: combine {run}_? only for run{1}
nruns=7; %# of sub runs
isnew=0; %if is an n version
yearstart=2001; %for plot window
nyear=20;
%time_left=datenum([yearstart,1,1]);
time_left=datenum([2015,1,1]);
time_right=datenum([yearstart+nyear,1,1]);

if isicm==1
    para_pk=[11,27,18,19,23,14,1];
else
    para_pk=[1 ]; %[1 2];
end %isicm
npara_pk=length(para_pk);

%figure properties
figuresize=[1,1,1250,550];
nfontsize=18;
ileg=1; %legend
%-----------------------------

%observation results
para_CBP={'SALINITY','WTEMP','verI t','zcor','PH','ZB1','ZB2','PB1','PB2','PB3','CHLA','TON','TON','DOC','TON','TON','DON','NH4F','NO23F','TOP','TOP','DOP','PO4F','SU','SIF','COD','DO','TIC','ALK','CA','CACO3','lfsav','stsav','rtsav','Canopy height','SOD','NH4 flux','NO3 flux','PO4 flux'};
para_NERR=cell(39); para_NERR{1}='Sal'; para_NERR{2}='Temp';
para_ERDDAP=cell(39); para_ERDDAP{1}='sea_water_practical_salinity'; para_ERDDAP{2}='sea_water_temperature';
para_USGS=cell(39); para_USGS{1}='Salinity';para_USGS{2}='Temperature';

%---------------------------------------------------------------------
%model + obs
for ireg=isregion
    for pp=1:length(run)

        %--------load model results--------
        if iscomb==0
            load([path_cloud,run{pp},'/',run{pp},'_model_',regions{ireg},'.mat']);
        elseif iscomb==1
            T_all=[];para_all=[];
            for qq=1:nruns
                if isnew==1
                    subrun=[run{pp},'_',num2str(qq),'n'];
                else
                    subrun=[run{pp},'_',num2str(qq)];
                end
                load([path_cloud,subrun,'/',subrun,'_model_',regions{ireg},'.mat']);
                T_all=[T_all;T]; clear T
                para_all=cat(1,para_all,para); clear para   
            end %qq::subruns
            [T,ia,~]=unique(T_all); clear T_all
            para=para_all(ia,:,:); clear para_all
        end %iscomb
%%
        %--------loop for each variable-------
        for para_nod=1:npara_pk
            %--splite into multiple figures--
            nfig=ceil(length(sta_md)/9);
            for r1=1:nfig %each figure for 9 stations
                figure('Position',figuresize);
                sta_pk=(9*r1-8):(min(9*r1,length(sta_md)));
                %sta_pk=[3 4];
                for sta_nod=1:length(sta_pk) %print each station
                    subplot(3,3,sta_nod)
                    hold on
                    if ireg==1||ireg==2||ireg==5
                        plot(T(:),para(1:length(T),sta_pk(sta_nod)*2,para_pk(para_nod)),'LineWidth',1.);
                        plot(T(:),para(1:length(T),sta_pk(sta_nod)*2+1,para_pk(para_nod)),'LineWidth',1.);
                    elseif ireg==6
                        plot(T(:),para(1:length(T),sta_pk(sta_nod)*2,para_pk(para_nod)),'LineWidth',1.);
                    else
                        plot(T(:),para(1:length(T),sta_pk(sta_nod)+1,para_pk(para_nod)),'LineWidth',1.);
                    end %surface w/ bottom

                    %*********************************************************************************
                    %-----observations-----
                    if ireg==1||ireg==2
                        Obs=GetWQData(sta_md{sta_pk(sta_nod)},para_CBP{para_pk(para_nod)},time_left,time_right,0);
                        %surface
                        sid=find(strcmp(Obs.Layer,'S ')); %surface
                        plot(Obs.Doy(sid),Obs.Data(sid),'.','Color',[0.4 0.4 0.4],'MarkerSize',15);
                        %bottom
                        bid=find(strcmp(Obs.Layer,'B ')); %bottom
                        plot(Obs.Doy(bid),Obs.Data(bid),'o','MarkerSize',6,'MarkerEdgeColor',[0.1 0.1 0.1]);            
                    elseif ireg==3
                        invar=para_NERR{para_pk(para_nod)};
                        instation=sta_md{sta_pk(sta_nod)};
                        [outtime,outvar]=NERR2TSeries(instation,invar,time_left,time_right);
                        if strcmp(invar,'Sal')
                            outvar(outvar>38)=nan;
                            outvar(outvar<0)=nan;
                        end          
                        if strcmp(invar,'Temp')
                            outvar(outvar>38)=nan;
                            outvar(outvar<-20)=nan;
                        end
                        plot(outtime,outvar);%,'.','MarkerSize',1)
                    elseif ireg==4
                        invar=para_ERDDAP{para_pk(para_nod)};
                        instation=sta_md{sta_pk(sta_nod)};
                        [outtime,outvar]=ERDDAP2TSeries(instation,invar,time_left,time_right);
                        if strcmp(invar,'sea_water_practical_salinity')
                            outvar(outvar>38)=nan;
                            outvar(outvar<0)=nan;
                        end                  
                        if ismember(instation,sta_md([10 11 12 13 14 15]))
                            ylim([32 38])
                        end
                        plot(outtime,outvar,'.','MarkerSize',2)
                    elseif ireg==5
                        invar=para_ERDDAP{para_pk(para_nod)};
                        instation=sta_md{sta_pk(sta_nod)};
                        [outtime,outvar]=APES2TSeries(instation,invar,time_left,time_right);
                        if strcmp(invar,'Sal')
                            outvar(outvar>38)=nan;
                            outvar(outvar<0)=nan;
                        end                  
                        plot(outtime,outvar,'.','Color',[0.3 0.3 0.3],'MarkerSize',8)
                    elseif ireg==6
                        invar=para_USGS{para_pk(para_nod)};
                        instation=sta_md{sta_pk(sta_nod)};
                        [outtime,outvar]=USGS2TSeries(instation,invar,time_left,time_right);
                        if strcmp(invar,'Salinity')
                            outvar(outvar>38)=nan;
                            outvar(outvar<0)=nan;
                        end       
                        outvar0=outvar;outtime0=outtime;
                        nd=1;int=1;
                        if ~isempty(outvar0)
                            [outtime,outvar]=Q_ave(outtime0,outvar0,nd,int);
                            plot(outtime,outvar,'.','Color',[0.3 0.3 0.3],'MarkerSize',8)
                            %plot(outtime,outvar,'LineWidth',1)
                        end %isempty
                        sta_md=string(sta_md);
                        if ismember(instation,sta_md([1:3]))
                            ylim([0 2])
                        end                        
                    end %ireg
                    
                    %figure properties
                    box on
                    if sta_nod==6 && ileg==1
                        if ireg==1||ireg==2
                            legend('model surface','model bottom','observation surface','observation bottom')
                        elseif ireg==5
                            legend('model surface','model bottom','observation')
                        else
                            legend('model','observation')
                        end
                    end
                    xlim([time_left time_right])
                    ylabel([para_name{para_pk(para_nod)},' (',para_unit{para_pk(para_nod)},')'],'fontsize',14)
                    title_str=strrep(sta_md{sta_pk(sta_nod)}, '_', ' ');
                    title(title_str)
                    datetick('x','yyyy','keeplimits') %,'keepticks')            
                    set(gca,'fontsize',nfontsize);
                end %sta_nod
                if isave==1
                    if ~exist([path_cloud,run{pp}],'dir')
                        system(['mkdir ',path_cloud,run{pp}])
                    end
                    outfile=[path_cloud,run{pp},'/',run{pp},'_',para_name{para_pk(para_nod)},'_',regions{ireg},'_',num2str(r1),'.png'];
                    set(gcf,'PaperPositionMode','auto') 
                    print('-dpng',outfile,'-r300')
                    close all
                end %isave
            end %r1::nfig
        end %para_nod

    end %pp::run
end %ireg



