clear
close all
clc
%scripts paths
addpath '/Users/ncai/OneDrive/Scripts/bin/'
addpath '/Users/ncai/OneDrive/Scripts/bin/TaylorDiagram/'
addpath '/Users/ncai/OneDrive/Scripts/bin/Target'

path_cloud='/Users/ncai/OneDrive/Projects/USEC/results/';

%----------inputs------------
isave=[];%1: save each para; 2: save total 
ileg=1;%flag to generate legend: 1:plot legend; 0: no legend
isicm=0;
isregion=[1:5]; %1: ChesBay main stem; 2: Ches tribs; 3: NERR_USEC; 4: ERDDAP_USEC; 5: NC APES
regions={'CBP','CBPTribs','NERR','ERDDAP','APES'};

run={'run03a'}; 
if isicm==1
    para_pk=[11,27,18,19,23,14,1];
else
    para_pk=1;%[1 2]; %[1 2];
end %isicm
npara_pk=length(para_pk);
para_name={'salt','temp','vert','zcor','PH','ZB1','ZB2','PB1','PB2','PB3','CHL','RPOC','LPOC','DOCA','RPON','LPON','DON','NH4','NO3','RPOP','LPOP','DOP','PO4','SU','SAt','COD','DO','TIC','ALK','CA','CACO3','lfsav','stsav','rtsav','Canopy height','SOD','NH4 flux','NO3 flux','PO4 flux','DIN'};
para_print={'Salinity','Temperature','vert','zcor','PH','ZB1','ZB2','PB1','PB2','PB3','CHL','RPOC','LPOC','DOCA','RPON','LPON','DON','NH4','NO3','RPOP','LPOP','DOP','PO4','SU','SAt','COD','DO','TIC','ALK','CA','CACO3','lfsav','stsav','rtsav','Canopy height','SOD','NH4 flux','NO3 flux','PO4 flux','DIN'};


for pp=1:length(run)
    %----------load stats------------
    infile=[path_cloud,run{pp},'/',run{pp},'_stats'];
    load([infile,'_Target.mat'])

    %*********************************************************************************       
    Bias=[];rmse=[];leg={};icount=0;   
    TBias=[];Trmse=[];Tleg={};Ticount=0;   
    %--------loop for each variable-------
    for para_nod=1:npara_pk
        RBias=[];Rrmse=[];Rleg={};Ricount=0;    
        for ireg=isregion
            field=[para_name{para_nod},'_region_',num2str(ireg)];
            data_target=StatsTarget.(field);
            %total target
            Bias=[Bias data_target.biasN];
            rmse=[rmse data_target.rmse_ubN]; 
            leg_tmp=[regions{ireg},' ', para_print{para_nod}];
            icount=icount+1;
            leg{icount}=leg_tmp;
            %target for only one para
            RBias=[RBias data_target.biasN];
            Rrmse=[Rrmse data_target.rmse_ubN]; 
            leg_tmp=[regions{ireg}];
            Ricount=Ricount+1;
            Rleg{Ricount}=leg_tmp;
            clear field data_target leg_tmp
        end %ireg

        %target for only one para
        field=[para_name{para_nod}];
        data_target=StatsTarget.(field);
        TBias=[TBias data_target.biasN];
        Trmse=[Trmse data_target.rmse_ubN]; 
        leg_tmp=[para_print{para_nod}];
        Ticount=Ticount+1;
        Tleg{Ticount}=leg_tmp;
        clear field data_target leg_tmp

        figure('Position',[1,1,1200,1200]);
        if ileg==1
            plot_target_diagram(RBias,Rrmse,Rleg,3,1,1);
        else
            plot_target_diagram(RBias,Rrmse,[],3,1,1);
        end %ileg
        set(gca,'FontSize', 25);
    
        if ismember(1,isave)
            outname=[run{pp},'_',para_name{para_nod},'_Target'];    
            set(gcf,'PaperPositionMode','auto') 
            print('-dpng',[path_cloud,run{pp},'/',outname,'.png'],'-r300') 
        end   
    end %para_nod
    
    %plot target for all para
    figure('Position',[1,1,1200,1200]);
    if ileg==1
        plot_target_diagram(Bias,rmse,leg,3,1,1);
    else
        plot_target_diagram(Bias,rmse,[],3,1,1);
    end %ileg
    set(gca,'FontSize', 25);

    figure('Position',[1,1,1200,1200]);
    if ileg==1
        plot_target_diagram(TBias,Trmse,Tleg,3,1,1);
    else
        plot_target_diagram(TBias,Trmse,[],3,1,1);
    end %ileg
    set(gca,'FontSize', 25);

    if ismember(2,isave)
        outname=[run{pp},'_Target'];    
        set(gcf,'PaperPositionMode','auto') 
        print('-dpng',[path_cloud,run{pp},'/',outname,'.png'],'-r300') 
    end   
end %pp::run





