clear
close all
clc
%scripts paths
addpath '/Users/ncai/OneDrive/Scripts/bin/'
addpath '/Users/ncai/OneDrive/Scripts/bin/TaylorDiagram/'
addpath '/Users/ncai/OneDrive/Scripts/bin/Target'

path_cloud='/Users/ncai/OneDrive/Projects/USEC/results/';

%----------inputs------------
ifig=[1 2];%1: all stations scattered; 2: singel scatter for all stations in each region
isave=[  ];
ileg=1;%flag to generate legend: 1:plot legend; 0: no legend
isicm=0;

%--methods to pick up model data for stats--
%1: interplation; 2: daily averaged
ipkdate=2; 
ipkreg=[3,4,6]; %regions to have daily average when ipkdate==2

isregion=[1:6]; %1: ChesBay main stem; 2: Ches tribs; 3: NERR_USEC; 4: ERDDAP_USEC; 5: NC APES; 6: USGSDB
% regions={'CBP','CBPTribs','NERR','ERDDAP','APES','USGSDB'};
regions={'CBP main strem','CBP tributaries','NERR','IOOS','ModMon','DRBC'};

run={'run05a_1n'}; 
if isicm==1
    para_pk=[11,27,18,19,23,14,1];
else
    para_pk=[1 2]; %[1 2];
end %isicm
npara_pk=length(para_pk);
para_name={'salinity','temperature','vert','zcor','PH','ZB1','ZB2','PB1','PB2','PB3','CHL','RPOC','LPOC','DOCA','RPON','LPON','DON','NH4','NO3','RPOP','LPOP','DOP','PO4','SU','SAt','COD','DO','TIC','ALK','CA','CACO3','lfsav','stsav','rtsav','Canopy height','SOD','NH4 flux','NO3 flux','PO4 flux','DIN'};
para_print={'Salinity','Temperature','vert','zcor','PH','ZB1','ZB2','PB1','PB2','PB3','CHL','RPOC','LPOC','DOCA','RPON','LPON','DON','NH4','NO3','RPOP','LPOP','DOP','PO4','SU','SAt','COD','DO','TIC','ALK','CA','CACO3','lfsav','stsav','rtsav','Canopy height','SOD','NH4 flux','NO3 flux','PO4 flux','DIN'};

%assign colors
colorvar0 = bl2rd_scaled(32);
%colorvar(6,:)=colorvar0(3,:); 
colorvar(3,:)=colorvar0(21,:);
colorvar(4,:)=colorvar0(32,:);
colorvar(1,:)=colorvar0(5,:);
colorvar(2,:)=colorvar0(11,:);
colorvar(5,:)=[0.4 0.4 0.4]; %colorvar0(13,:);
colorvar(6,:)=colorvar0(26,:);

for pp=1:length(run)
    %----------load stats------------
    infile=[path_cloud,run{pp},'/',run{pp},'_stats'];
    if ipkdate==2
        infile=[infile,'_davrg'];
    end     
    load([infile,'_TaylorDiagram.mat'])

    %--------loop for each variable-------

    %*********************************************************************************  
    if ismember(1,ifig)
        %plot all stations
        figure('Position',[1,1,900,450]);
        for para_nod=1:npara_pk
            subplot(1,2,para_nod)
            data_TD=[];
            
            for ireg=isregion
                rid=find(isregion==ireg);
                field=[para_name{para_nod},'_region_',num2str(ireg)];
                data=StatsTD.(field);
                data_TD=[data_TD data]; 
                ndata_TD(rid)=length(data);clear data
            end %ireg
            data_TD=[[1;0;1] data_TD];
            TD = STaylorDiag(data_TD);
            
            for ireg=isregion
                rid=find(isregion==ireg);
                for ii=1:ndata_TD(rid)
                    if rid==1
                        tid=ii;
                    else
                        tid=sum(ndata_TD(1:rid-1))+ii;
                    end
                    TD.SPlot(data_TD(1,tid),data_TD(2,tid),data_TD(3,tid),'Marker','.','MarkerSize',25,'Color',colorvar(ireg,:));  
                end
            end %ireg
            TD.set('SLim',[0,2])
            TD.set('RLim',[0,1.5])
            TD.set('STickValues',0:0.5:2)
            TD.set('RTickValues',0.5:0.5:1.5)
            % TD.set('STickLabelX','FontSize',22)
            TD.set('STickLabelY','FontSize',22)
            TD.set('RTickLabel','FontSize',22)
            TD.set('CTickLabel','FontSize',22)
        end %para_nod
        if ismember(1,isave)
            outname=[run{pp},'_USEC_TD_station'];
            if ipkdate==2
                outname=[outname,'_davrg'];
            end         
            set(gcf,'PaperPositionMode','auto') 
            print('-dpng',[path_cloud,run{pp},'/',outname,'.png'],'-r300')
        end
    end % ifig

    %*********************************************************************************  
    %plot regions
    if ismember(2,ifig)
        figure('Position',[1,1,900,450]);
        for para_nod=1:npara_pk
            subplot(1,2,para_nod)        
            field=[para_name{para_nod}];
            data_TD=StatsTD.(field);
            data_TD=[[1;0;1] data_TD];
            TD = STaylorDiag(data_TD);
            for ii=2:size(data_TD,2)
                TD.SPlot(data_TD(1,ii),data_TD(2,ii),data_TD(3,ii),'Marker','.','MarkerSize',45,'Color',colorvar(ii-1,:));
                % TD.SText(data_TD(1,ii),data_TD(2,ii),data_TD(3,ii),"   "+string(regions{ii-1}),'FontSize',16,...
                %     'VerticalAlignment','middle','HorizontalAlignment','left');            
            end %ii::size(data_TD,2)
            TD.set('SLim',[0,2])
            TD.set('RLim',[0,1.5])
            TD.set('STickValues',0:0.5:2)
            TD.set('RTickValues',0.5:0.5:1.5)
            % TD.set('STickLabelX','FontSize',22)
            TD.set('STickLabelY','FontSize',22)
            TD.set('RTickLabel','FontSize',22)
            TD.set('CTickLabel','FontSize',22)
          
        end %para_nod
        if ismember(2,isave)
            outname=[run{pp},'_USEC_TD_ttstation'];
            if ipkdate==2
                outname=[outname,'_davrg'];
            end 
            set(gcf,'PaperPositionMode','auto') 
            print('-dpng',[path_cloud,run{pp},'/',outname,'.png'],'-r300')
        end
    end %ifig
end %pp::run












%--------------STaylorDiag mannual--------------
% % Set other properties(设置其他属性)
% TD.set('TickLength',[.015,.05])
% TD.set('SLim',[0,300])
% TD.set('RLim',[0,175])
% TD.set('STickValues',0:50:300)
% TD.set('SMinorTickValues',0:25:300)
% TD.set('RTickValues',0:25:175)
% TD.set('CTickValues',[.1,.2,.3,.4,.5,.6,.7,.8,.9,.95,.99])
% 
% % Set Grid(修饰各个网格)
% TD.set('SGrid','Color',[.7,.7,.7],'LineWidth',1.5)
% TD.set('RGrid','Color',[.77,.6,.18],'LineWidth',1.5)
% TD.set('CGrid','Color',[0,0,.8],'LineStyle',':','LineWidth',.8);
% 
% % Set Tick Label(修饰刻度标签)
% TD.set('STickLabelX','Color',[.8,0,0],'FontWeight','bold')
% TD.set('STickLabelY','Color',[.8,0,0],'FontWeight','bold')
% TD.set('RTickLabel','Color',[.77,.6,.18],'FontWeight','bold')
% TD.set('CTickLabel','Color',[0,0,.8],'FontWeight','bold')
% 
% % Set Label(修饰标签)
% TD.set('SLabel','Color',[.8,0,0],'FontWeight','bold')
% TD.set('CLabel','Color',[0,0,.8],'FontWeight','bold')
% 
% % Set Axis(修饰各个轴)
% TD.set('SAxis','Color',[.8,0,0],'LineWidth',2)
% TD.set('CAxis','Color',[0,0,.8],'LineWidth',2)
% 
% % Set Tick and MinorTick(修饰主次刻度)
% TD.set('STick','Color',[.8,0,0],'LineWidth',8)
% TD.set('CTick','Color',[0,0,.8],'LineWidth',8)
% TD.set('SMinorTick','Color',[.8,0,0],'LineWidth',5)
% TD.set('CMinorTick','Color',[0,0,.8],'LineWidth',5)














