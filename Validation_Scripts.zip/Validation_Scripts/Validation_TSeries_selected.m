clear
close all
clc
addpath '/Users/ncai/OneDrive/Scripts/bin/'
addpath '/Users/ncai/OneDrive/Database/Ches_Database/CBP_database/'
addpath '/Users/ncai/OneDrive/Database/NERR/bpfiles/'
addpath '/Users/ncai/Library/CloudStorage/OneDrive-Personal/Database/NERR/bin/'
addpath '/Users/ncai/OneDrive/Database/NOAA_ERDDAP/bin/'
addpath '/Users/ncai/OneDrive/Database/NOAA_ERDDAP/'
addpath '/Users/ncai/OneDrive/Database/NC_APES_ModMon/'
addpath '/Users/ncai/OneDrive/Database/USGS_WQ/bin/'
addpath '/Users/ncai/OneDrive/Database/USGS_WQ/DelawareBay/'
lversion=4; %loading version
path_grid=['/Users/ncai/OneDrive/Projects/USEC/Grid_v',num2str(lversion),'/'];
path_cloud='/Users/ncai/OneDrive/Projects/USEC/results/';
hgridmat=['Grid_v',num2str(lversion)];

%----------inputs------------
isave=0;%flag to save the figure, png
isicm=0;
%1: ChesBay main stem; 2: Ches tribs; 3: NERR_USEC; 4: ERDDAP_USEC; 5: NC APES; 6:USGSDB
regions={'CBP','CBPTribs','NERR','ERDDAP','APES','USGSDB'};
regions_name={'CBP','CBP','NERR','IOOS','ModMon','DRBC'};
regsta=[6,15,7,25,14,4];

run_base='run05a'; 
iscomb=1; %1: combine {run}_? only for run{1}
nruns=7; %# of sub runs
isnew=0; %if is an n version
yearstart=2001; %for plot window
nyear=20;
time_left=datenum([yearstart,1,1]);
time_right=datenum([yearstart+nyear,1,1]);

para_pk=[1]; %salinity


%figure properties
nfontsize=20;
%-----------------------------

%observation results
para_CBP={'SALINITY','WTEMP','verI t','zcor','PH','ZB1','ZB2','PB1','PB2','PB3','CHLA','TON','TON','DOC','TON','TON','DON','NH4F','NO23F','TOP','TOP','DOP','PO4F','SU','SIF','COD','DO','TIC','ALK','CA','CACO3','lfsav','stsav','rtsav','Canopy height','SOD','NH4 flux','NO3 flux','PO4 flux'};
para_NERR=cell(39); para_NERR{1}='Sal'; para_NERR{2}='Temp';
para_ERDDAP=cell(39); para_ERDDAP{1}='sea_water_practical_salinity'; para_ERDDAP{2}='sea_water_temperature';
para_USGS=cell(39); para_USGS{1}='Salinity';para_USGS{2}='Temperature';
%---------------------------------------------------------------------



%---------------------------------------------------------------------
%TSeries 
%---------------------------------------------------------------------
fsize=[1,1,1200,700];
figure('Position',fsize)
for para_nod=1:length(para_pk)
    for ireg=1:length(regions)
        subplot(3,2,ireg)
    
        %---------find station location---------
        fname=['USEC_ll_',regions{ireg},'.mat'];
        load(fname)
        lonlat_pk(ireg,:)=lonlat(regsta(ireg),1:2);
        %--------------------------------------

        %----------load model results----------
        if iscomb==0
            load([path_cloud,run_base,'/',run_base,'_model_',regions{ireg},'.mat']);
        elseif iscomb==1
            T_all=[];para_all=[];
            for qq=1:nruns
                if isnew==1
                    subrun=[run_base,'_',num2str(qq),'n'];
                else
                    subrun=[run_base,'_',num2str(qq)];
                end
                load([path_cloud,subrun,'/',subrun,'_model_',regions{ireg},'.mat']);
                T_all=[T_all;T]; clear T
                para_all=cat(1,para_all,para); clear para   
            end %qq::subruns
            [T,ia,~]=unique(T_all); clear T_all
            para=para_all(ia,:,:); clear para_all
        end %iscomb
    
        hold on
        if ireg==1||ireg==2||ireg==5
            plot(T(:),para(1:length(T),regsta(ireg)*2,para_pk(para_nod)),'LineWidth',1.);
            plot(T(:),para(1:length(T),regsta(ireg)*2+1,para_pk(para_nod)),'LineWidth',1.);
        elseif ireg==6
            plot(T(:),para(1:length(T),regsta(ireg)*2,para_pk(para_nod)),'LineWidth',1.);
        else
            plot(T(:),para(1:length(T),regsta(ireg)+1,para_pk(para_nod)),'LineWidth',1.);
        end %surface w/ bottom
        %----------------------------------------
    
        %-----------load observations-----------    
        if ireg==1||ireg==2
            Obs=GetWQData(sta_md{regsta(ireg)},para_CBP{para_pk(para_nod)},time_left,time_right,0);
            %surface
            sid=find(strcmp(Obs.Layer,'S ')); %surface
            plot(Obs.Doy(sid),Obs.Data(sid),'.','Color',[0.3 0.3 0.3],'MarkerSize',10);
            %bottom
            bid=find(strcmp(Obs.Layer,'B ')); %bottom
            plot(Obs.Doy(bid),Obs.Data(bid),'o','MarkerSize',5,'MarkerEdgeColor',[0.1 0.1 0.1]);            
        elseif ireg==3
            invar=para_NERR{para_pk(para_nod)};
            instation=sta_md{regsta(ireg)};
            [outtime,outvar]=NERR2TSeries(instation,invar,time_left,time_right);
            if strcmp(invar,'Sal')
                outvar(outvar>38)=nan;
                outvar(outvar<0)=nan;
            end          
            if strcmp(invar,'Temp')
                outvar(outvar>38)=nan;
                outvar(outvar<-20)=nan;
            end
            outvar0=outvar;outtime0=outtime;
            nd=1;int=5;
            if ~isempty(outvar0)
                [outtime,outvar]=Q_ave(outtime0,outvar0,nd,int);
                plot(outtime,outvar,'.','Color',[0.3 0.3 0.3],'MarkerSize',8)
                %plot(outtime,outvar,'LineWidth',1)
            end %isempty                        
        elseif ireg==4
            invar=para_ERDDAP{para_pk(para_nod)};
            instation=sta_md{regsta(ireg)};
            [outtime,outvar]=ERDDAP2TSeries(instation,invar,time_left,time_right);
            if strcmp(invar,'sea_water_practical_salinity')
                outvar(outvar>38)=nan;
                outvar(outvar<0)=nan;
            end                  
            if ismember(instation,sta_md([10 11 12 13 14 15]))
                ylim([32 38])
            end
            outvar0=outvar;outtime0=outtime;
            nd=1;int=5;
            if ~isempty(outvar0)
                [outtime,outvar]=Q_ave(outtime0,outvar0,nd,int);
                plot(outtime,outvar,'.','Color',[0.3 0.3 0.3],'MarkerSize',8)
                %plot(outtime,outvar,'LineWidth',1)
            end %isempty                        

        elseif ireg==5
            invar=para_ERDDAP{para_pk(para_nod)};
            instation=sta_md{regsta(ireg)};
            [outtime,outvar]=APES2TSeries(instation,invar,time_left,time_right);
            if strcmp(invar,'Sal')
                outvar(outvar>38)=nan;
                outvar(outvar<0)=nan;
            end                  
            outvar0=outvar;outtime0=outtime;
            [outtime,~,ic]=unique(outtime0);
            outvar_max = accumarray(ic, outvar0, [], @max); % Compute max for each group
            outvar_min = accumarray(ic, outvar0, [], @min); % Compute min for each group
            plot(outtime,outvar_min,'.','Color',[0.3 0.3 0.3],'MarkerSize',10);
            plot(outtime,outvar_max,'o','MarkerSize',5,'MarkerEdgeColor',[0.1 0.1 0.1]);   
        elseif ireg==6
            invar=para_USGS{para_pk(para_nod)};
            instation=sta_md{regsta(ireg)};
            [outtime,outvar]=USGS2TSeries(instation,invar,time_left,time_right);
            if strcmp(invar,'Salinity')
                outvar(outvar>38)=nan;
                outvar(outvar<0)=nan;
            end       
            outvar0=outvar;outtime0=outtime;
            nd=1;int=5;
            if ~isempty(outvar0)
                [outtime,outvar]=Q_ave(outtime0,outvar0,nd,int);
                plot(outtime,outvar,'.','Color',[0.3 0.3 0.3],'MarkerSize',8)
                %plot(outtime,outvar,'LineWidth',1)
            end %isempty
            sta_md=string(sta_md);
            if ismember(instation,sta_md([1:3]))
                ylim([0 2])
            end                        
        end %ireg


        %figure properties
        box on
        xlim([time_left time_right])
        title_str=strrep(sta_md{regsta(ireg)}, '_', ' ');
        if ireg==5
            title_str='ps2';
        end
        title([regions_name{ireg},': ',title_str])
        datetick('x','yyyy','keeplimits') %,'keepticks')            

        if ireg==4
            ylim([29 37])
        elseif ireg==3
            ylim([12 35])
        elseif ireg==2
            ylim([3 22])
        elseif ireg==1
            ylim([0 25])
        end

        if ireg<=4
            xticks([])
        end

        if ireg==1||ireg==3||ireg==5
            ylabel([para_name{para_pk(para_nod)},' (',para_unit{para_pk(para_nod)},')'],'fontsize',14)
        end

        if ireg==0
            legend('model surface','model bottom','observation surface','observation bottom')
        end
        set(gca,'fontsize',nfontsize);

        %----------------------------------------
    
    end %ireg
    
    if isave==1
    outfile=[path_cloud,run_base,'/',run_base,'_',para_name{para_pk(para_nod)},'_regpk_TSeries.png'];
    set(gcf,'PaperPositionMode','auto') 
    print('-dpng',outfile,'-r300')    
    end %save

end %para_nod
%---------------------------------------------------------------------



%---------------------------------------------------------------------
%horizontal map
%---------------------------------------------------------------------
figdim=[1,1,350,300];
figure('Position',figdim)
xdim=[-82 -63];
ydim=[30.5 46];

load([path_grid,hgridmat,'.mat']);
for i=1:length(open_bnds)
    line(lonlat(open_bnds{i},2),lonlat(open_bnds{i},3),'LineWidth',1,'Color','k'); hold on;
end
for i=1:length(land_bnds)
    line(lonlat(land_bnds{i},2),lonlat(land_bnds{i},3),'LineWidth',1,'Color','k'); hold on;
    if ilb_island(i)==1 %island
        nd1=land_bnds{i}(end); nd2=land_bnds{i}(1);
        line(lonlat([nd1 nd2],2),lonlat([nd1 nd2],3),'LineWidth',1,'Color','k'); hold on;
    end
end    

sz=1200;

colorvar0 = bl2rd_scaled(32);
colorvar(6,:)=colorvar0(26,:);
colorvar(3,:)=colorvar0(21,:);
colorvar(4,:)=colorvar0(32,:);
colorvar(1,:)=colorvar0(5,:);
colorvar(2,:)=colorvar0(11,:);
colorvar(5,:)=[0.7 0.7 0.7]; %colorvar0(13,:);
for ireg=1:length(regions)
    s1=scatter(lonlat_pk(ireg,1),lonlat_pk(ireg,2),sz,colorvar(ireg,:),'.');
end %ireg

box on
set(gca,'FontSize',nfontsize)
xlim(xdim)
ylim(ydim)

if isave==1
    outfile=[path_cloud,run_base,'/',run_base,'_',para_name{para_pk(para_nod)},'_regpk.png'];
    set(gcf,'PaperPositionMode','auto') 
    print('-dpng',outfile,'-r300')
end %
%---------------------------------------------------------------------










