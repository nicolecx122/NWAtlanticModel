clear
close all
clc

addpath '/Users/ncai/OneDrive/Scripts/bin/'
addpath '/Users/ncai/OneDrive/Database/NOAA_currents/'

path_cloud='/Users/ncai/OneDrive/Projects/USEC/results/';

%----------inputs------------
isave=0;
run='run05a'; 
iscomb=1; %1: combine {run}_?
nruns=7; %# of sub runs
year_ori=2001; %from model start time

%for window on obs
time_left=datenum(['3/06/2008 00:00:00']);
time_right=datenum(['3/23/2008 00:00:00']);

%station choices
istapk=1; %0: plot all stations; 1: plot sta_pk stations
sta_pk=[15 14 9 4];%[4 9 14 15 ]; %18

%-----figure parameters-----
nsub=length(sta_pk);
figuresize=[1,1,750,200*nsub];
nfontsize=22;
clbase=bl2rd_scaled(64);
%-----------------------------

%-----time and variables-----
time_ori=datenum(['01/01/',num2str(year_ori),' 00:00:00']);
window=time_left:(1/24):time_right; %(time_left+nyear*365);
para={'Velocity (m s^-^1)','Degree'};


%------------read in station info------------
load('/Users/ncai/Library/CloudStorage/OneDrive-Personal/Database/NOAA_currents/NOAA_currents_USEC.mat')
nsta=length(staid);
sinitid=65; %starting station id for velocity


%--------------------------------------------------------------------
%load and plot model vs. obs
%--------------------------------------------------------------------

%------------load model results------------
if iscomb==0
    path=[path_cloud,run,'/'];
    %--pick u--
    fname=[run,'_u_sta.mat'];
    load([path,fname]) 
    mtime1=T/86400; clear T
    xvar=var; clear var
    xvar(xvar<-99)=nan;
    %--pick v--
    fname=[run,'_v_sta.mat'];
    load([path,fname]) 
    mtime2=T/86400; clear T
    yvar=var; clear var
    yvar(yvar<-99)=nan;
    %--pick compatible u,v--
    [mtime,ia,ib]=intersect(mtime1,mtime2);
    mtime=time_ori+mtime;
    xvar=xvar(ia,:);yvar=yvar(ib,:);
elseif iscomb==1
    mtime=[];xvar=[];yvar=[];
    for r1=1:nruns
        %--pick u--
        subrun=[run,'_',num2str(r1)];
        fname=[subrun,'_u_sta.mat'];
        load([path_cloud,subrun,'/',fname]) 
        submtime1=T/86400; clear T
        subxvar=var; clear var
        subxvar(subxvar<-99)=nan;
        %--pick v--
        fname=[subrun,'_v_sta.mat'];
        load([path_cloud,subrun,'/',fname]) 
        submtime2=T/86400; clear T
        subyvar=var; clear var
        subyvar(subyvar<-99)=nan;
        %--pick compatible u,v--
        [submtime,ia,ib]=intersect(submtime1,submtime2);
        subxvar=subxvar(ia,:);subyvar=subyvar(ib,:);
        if r1==1
            submtime=time_ori+submtime;
            mtime=[mtime;submtime];
        else
            submtime=mtime(end)+submtime;
            mtime=[mtime;submtime];
        end
        xvar=[xvar;subxvar];
        yvar=[yvar;subyvar];
    end %r1::nruns
end %iscomb
%pick current station outputs
xvar=xvar(:,sinitid:end); yvar=yvar(:,sinitid:end);
mvar=hypot(xvar, yvar);
mdirvar=atan2(yvar,xvar); mdirvar=rad2deg(mdirvar)+180;

%------------plot model vs. obs------------
if istapk==1
    nfig=1;
else
    nfig=ceil(length(staid)/nsub);
end %istapk

for r1=1:nfig
    figure('Position',figuresize);

    if istapk==0 %renew sta_pk
        sta_pk=(nsub*r1-3):(min(nsub*r1,length(staid)));
    end %istapk

    for sta_nod=1:length(sta_pk)   
        %--read obs--
        [otime,ovar,odirvar]=NOAA_currents_TSeries(staid{sta_pk(sta_nod)},window(1)-1,window(end)+1);
        
        %--plot vel--
        %subplot(nsub,1,sta_nod*2-1)        
        subplot(nsub,1,sta_nod)
        plot(mtime,mvar(:,sta_pk(sta_nod)),'LineWidth',3.); hold on
        plot(otime,ovar,'.','Color',[1 1 1]/3,'MarkerSize',6)
        title(staid{sta_pk(sta_nod)}) 
        xlim([window(1) window(end)])
        
        if sta_nod==length(sta_pk)
            %xticks(window(1):4:window(end))
            datetick('x',23,'keeplimits','keepticks')            
        else 
            xticks([])
        end
        if strcmp(staid{sta_pk(sta_nod)},'cb1001')
            ylabel(para{1})
            legend('model','observation','Location','northwest')
        end
        set(gca,'fontsize',nfontsize);

        % %--plot direction--
        % subplot(nsub,2,sta_nod*2)        
        % plot(mtime,mdirvar(:,sta_pk(sta_nod)),'LineWidth',2); hold on
        % plot(otime,odirvar)    
        % title(staid{sta_pk(sta_nod)})
        % ylabel(para{2})
        % xlim([window(1) window(end)])
        % datetick('x','mmmDDyyyy','keeplimits')
        % set(gca,'fontsize',nfontsize);
    end %r1::sta

end %r1=nfig


if ismember(2,isave)
    outname=[run,'_USEC_currents'];
    set(gcf,'PaperPositionMode','auto') 
    print('-dpng',[path_cloud,run,'/',outname,'.png'],'-r300')
end

















